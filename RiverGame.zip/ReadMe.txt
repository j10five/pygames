After uncompressing the zip file:
1.	open the “dist” folder
2.	find and launch the “River.exe” app file 
  